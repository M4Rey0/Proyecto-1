package com.dpoo.Persistencia.usuarios;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.Usuario;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;

public class PersistenciaUsuarios {
    private static final String DIR_PATH = "dpoo/data/entidades/usuarios/";

    public static void guardarEstudiante(Usuario usuario) {
        String path = DIR_PATH + usuario.getId() + ".txt";
        try {
            FileWriter writer = new FileWriter(path);
            writer.write(usuario.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void guardarProfesor(Usuario usuario) {
        String path = DIR_PATH + usuario.getId() + ".txt";
        try {
            FileWriter writer = new FileWriter(path);
            writer.write(usuario.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void guardarUsuarios(HashMap<Integer, Usuario> usuarios) {
        for (Usuario usuario : usuarios.values()) {
            if (usuario.getTipo().equals("Estudiante")) {
                guardarEstudiante(usuario);
            } else if (usuario.getTipo().equals("Profesor")) {
                guardarProfesor(usuario);
            }
        }
    }

    public static void guardarUsuario(Usuario usuario) {
        if (usuario.getTipo().equals("Estudiante")) {
            guardarEstudiante(usuario);
        } else if (usuario.getTipo().equals("Profesor")) {
            guardarProfesor(usuario);
        }
    }

    public static HashMap<Integer, Usuario> cargarUsuarios(HashMap<Integer, Actividad> actividades) {
        HashMap<Integer, Usuario> usuarios = new HashMap<>();

        File dir = new File(DIR_PATH);
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles((d, name) -> name.endsWith(".txt"));
            if (files != null) {
                for (File file : files) {
                    try {
                        String content = new String(Files.readAllBytes(Paths.get(file.getPath())),
                                StandardCharsets.UTF_8);
                        // Assuming Usuario has a static method fromString to parse the content
                        Usuario usuario = FactoryUsuarios.cargarUsuario(content.split("\n"), actividades);
                        usuarios.put(usuario.getId(), usuario);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        return usuarios;
    }
}
