package com.dpoo.Persistencia.actividades;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;

import com.dpoo.Entidades.Actividad;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class PersistenciaActividades {

    private static final String DIR_PATH = "dpoo/data/entidades/actividades/";

    public static void guardarActividad(Actividad actividad) {
        String path = DIR_PATH + actividad.getId() + ".txt";
        try {
            FileWriter writer = new FileWriter(path);
            writer.write(actividad.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Actividad cargarActividad(String[] content) {
        return FactoryActividades.cargarActividad(content);
    }

    public static HashMap<Integer, Actividad> cargarActividades() {
        HashMap<Integer, Actividad> actividades = new HashMap<>();
        File dir = new File(DIR_PATH);
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File file : files) {
                    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                        String content = new String(Files.readAllBytes(Paths.get(file.getPath())),
                                StandardCharsets.UTF_8);
                        String[] parts = content.split("\n");
                        Actividad actividad = cargarActividad(parts);
                        actividades.put(actividad.getId(), actividad);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return actividades;
    }
}
