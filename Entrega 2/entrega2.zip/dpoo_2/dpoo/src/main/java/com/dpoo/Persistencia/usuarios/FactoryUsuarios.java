package com.dpoo.Persistencia.usuarios;

import java.util.HashMap;

import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.Usuario;
import com.dpoo.Entidades.usuarios.Estudiante;
import com.dpoo.Entidades.usuarios.Profesor;

public class FactoryUsuarios {
    public static Usuario cargarUsuario(String[] datos, HashMap<Integer, Actividad> actividades) {
        if (datos[4].equals("Estudiante")) {
            return cargarEstudiante(datos);
        } else if (datos[4].equals("Profesor")) {
            return cargarProfesor(datos, actividades);
        }
        return null;
    }

    private static Estudiante cargarEstudiante(String[] datos) {
        Estudiante estudiante = new Estudiante(Integer.parseInt(datos[0]), datos[1], datos[2], datos[3]);
        for (int i = 5; i < datos.length; i++) {
            estudiante.addLearningPath(Integer.parseInt(datos[i]));
        }

        return estudiante;
    }

    private static Profesor cargarProfesor(String[] datos, HashMap<Integer, Actividad> actividades) {
        Profesor profesor = new Profesor(Integer.parseInt(datos[0]), datos[1], datos[2], datos[3]);
        for (int i = 5; i < datos.length; i++) {
            profesor.addActividad(actividades.get(Integer.parseInt(datos[i])));
        }

        return profesor;
    }
}
