package com.dpoo.Persistencia.estructuras;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;

import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.LearningPath;
import com.dpoo.Entidades.usuarios.Estudiante;
import com.dpoo.Estructuras.ProgresoLearningPath;
import com.dpoo.Persistencia.actividades.PersistenciaActividades;
import com.dpoo.Persistencia.actividades.PersistenciaLearningPaths;

public class PersistenciaProgreso {

    private static final String DIR_PATH = "dpoo/data/estructuras/progresoEstudiantes/";

    public static void guardarProgreso(ProgresoLearningPath progreso) {
        // Guardar el progreso del estudiante en el learning path
        String path = DIR_PATH + progreso.getEstudiante() + "_" + progreso.getLearningPath().getId() + ".txt";

        try {
            FileWriter writer = new FileWriter(path);
            writer.write(progreso.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static ProgresoLearningPath cargarProgreso(String[] content, HashMap<Integer, LearningPath> learningPaths, HashMap<Integer, Estudiante> estudiantes) {
        // Cargar el progreso del estudiante en el learning path
        return ProgresoLearningPath.cargarDesdeString(content, learningPaths, estudiantes);
    }

    public static ArrayList<ProgresoLearningPath> cargarProgresos(HashMap<Integer, LearningPath> learningPaths, HashMap<Integer, Estudiante> estudiantes) {
        // Cargar todos los progresos de los estudiantes en los learning paths
        ArrayList<ProgresoLearningPath> progresos = new ArrayList<>();
        try {
            Files.list(Paths.get(DIR_PATH)).forEach(path -> {
                try {
                    String content = new String(Files.readAllBytes(path));
                    String[] lines = content.split("\n");
                    ProgresoLearningPath progreso = cargarProgreso(lines, learningPaths, estudiantes);
                    progresos.add(progreso);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return progresos;
    }
}
