package com.dpoo.Gestores;

import java.util.ArrayList;
import java.util.HashMap;

import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.LearningPath;
import com.dpoo.Entidades.usuarios.Estudiante;
import com.dpoo.Estructuras.ProgresoLearningPath;
import com.dpoo.Persistencia.actividades.PersistenciaLearningPaths;
import com.dpoo.Persistencia.estructuras.PersistenciaProgreso;

public class GestorLearningPaths {
    private HashMap<Integer, LearningPath> learningPaths = new HashMap<>();
    private HashMap<Integer, ArrayList<Integer>> estudiantesInscritos = new HashMap<>();
    private HashMap<Integer, HashMap<Integer, ProgresoLearningPath>> progresoEstudiantes = new HashMap<>();
    //Estructura de estudiantesInscritos: <learningPathId, ArrayList<estudianteId>>

    public void agregarLearningPath(LearningPath learningPath) {
        learningPaths.put(learningPath.getId(), learningPath);
        PersistenciaLearningPaths.guardarLearningPath(learningPath);
    }

    public void inscribirEstudiante(int learningPathId, int estudianteId, boolean carga) {
        if (!estudiantesInscritos.containsKey(learningPathId)) {
            estudiantesInscritos.put(learningPathId, new ArrayList<>());
        }
        estudiantesInscritos.get(learningPathId).add(estudianteId);
        LearningPath learningPath = learningPaths.get(learningPathId);
        if (!progresoEstudiantes.containsKey(learningPathId)) {
            progresoEstudiantes.put(learningPathId, new HashMap<>());
        }
        progresoEstudiantes.get(learningPath.getId()).put(estudianteId, new ProgresoLearningPath(learningPath, estudianteId));
        learningPath.agregarEstudiante(estudianteId);
        
        if (!carga) {
            PersistenciaLearningPaths.guardarLearningPath(learningPath);
            PersistenciaProgreso.guardarProgreso(progresoEstudiantes.get(learningPath.getId()).get(estudianteId));
        }
    }

    public void desinscribirEstudiante(int learningPathId, int estudianteId) {
        if (estudiantesInscritos.containsKey(learningPathId)) {
            estudiantesInscritos.get(learningPathId).remove(estudianteId);
        }
    }

    public ArrayList<Integer> obtenerEstudiantesInscritos(int learningPathId) {
        if (estudiantesInscritos.containsKey(learningPathId)) {
            return estudiantesInscritos.get(learningPathId);
        }
        return new ArrayList<>();
    }

    public LearningPath obtenerLearningPath(int learningPathId) {
        return learningPaths.get(learningPathId);
    }

    public ProgresoLearningPath obtenerProgresoEstudiante(Estudiante estudiante, int idLearningPath){
        if (!progresoEstudiantes.containsKey(idLearningPath)) {
            progresoEstudiantes.put(idLearningPath, new HashMap<>());
        }
        if (!progresoEstudiantes.get(idLearningPath).containsKey(estudiante.getId())) {
            progresoEstudiantes.get(idLearningPath).put(estudiante.getId(), new ProgresoLearningPath(learningPaths.get(idLearningPath), estudiante.getId()));
        }
        return progresoEstudiantes.get(idLearningPath).get(estudiante.getId());
    }

    public void agregarActividadALearningPath(Actividad actividad, int idLearningPath) {
        learningPaths.get(idLearningPath).agregarActividad(actividad);
        PersistenciaLearningPaths.guardarLearningPath(learningPaths.get(idLearningPath));
    }

    public void quitarActividadDeLearningPath(int actividadId, int idLearningPath) {
        learningPaths.get(idLearningPath).removerActividad(actividadId);
    }

    public void borrarLearningPath(int id) {
        learningPaths.remove(id);
        estudiantesInscritos.remove(id);
        progresoEstudiantes.remove(id);
    }

    public void cambiarProgresoActividad(int idLearningPath, int actividadId, int estudianteId, int progreso) {
        if (progresoEstudiantes.containsKey(idLearningPath) && progresoEstudiantes.get(idLearningPath).containsKey(estudianteId)) {
            progresoEstudiantes.get(idLearningPath).get(estudianteId).cambiarProgresoActividad(actividadId, progreso);
        }
    }

    public void cargarLearningPaths(HashMap<Integer, Actividad> actividades, HashMap<Integer, Estudiante> estudiantes) {
        learningPaths = PersistenciaLearningPaths.cargarLearningPaths(actividades);
        for (LearningPath learningPath : learningPaths.values()) {
            for (Integer estudianteId : learningPath.getEstudiantes()) {
                if (!estudiantesInscritos.containsKey(learningPath.getId())) {
                    estudiantesInscritos.put(learningPath.getId(), new ArrayList<>());
                }
                estudiantesInscritos.get(learningPath.getId()).add(estudianteId);
            }
        }
        ArrayList<ProgresoLearningPath> progresos = PersistenciaProgreso.cargarProgresos(learningPaths, estudiantes);
        for (ProgresoLearningPath progreso : progresos) {
            if (!progresoEstudiantes.containsKey(progreso.getLearningPath().getId())) {
                progresoEstudiantes.put(progreso.getLearningPath().getId(), new HashMap<>());
            }
            progresoEstudiantes.get(progreso.getLearningPath().getId()).put(progreso.getEstudiante(), progreso);
        }
    }

    public HashMap<Integer, LearningPath> getLearningPaths() {
        return learningPaths;
    }

    public void setLearningPaths(HashMap<Integer, LearningPath> learningPaths) {
        this.learningPaths = learningPaths;
    }

    public HashMap<Integer, ArrayList<Integer>> getEstudiantesInscritos() {
        return estudiantesInscritos;
    }

    public void setEstudiantesInscritos(HashMap<Integer, ArrayList<Integer>> estudiantesInscritos) {
        this.estudiantesInscritos = estudiantesInscritos;
    }

    public HashMap<Integer, HashMap<Integer, ProgresoLearningPath>> getProgresoEstudiantes() {
        return progresoEstudiantes;
    }

    public void setProgresoEstudiantes(HashMap<Integer, HashMap<Integer, ProgresoLearningPath>> progresoEstudiantes) {
        this.progresoEstudiantes = progresoEstudiantes;
    }
}
