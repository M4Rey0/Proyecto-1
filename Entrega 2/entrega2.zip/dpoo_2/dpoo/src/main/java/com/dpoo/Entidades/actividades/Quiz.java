package com.dpoo.Entidades.actividades;

import java.util.HashMap;

import com.dpoo.Entidades.Actividad;

public class Quiz extends Actividad{

    private HashMap<Integer, Pregunta> preguntas = new HashMap<>();
    private int puntajeMinimo;

    public Quiz(int id, String nombre, String descripcion, String objetivo, String nivel, int duracion, int puntajeMinimo, int autorId) {
        super(nombre, descripcion, objetivo, nivel,duracion, autorId);
        this.puntajeMinimo = puntajeMinimo;
    }

    public Quiz(String nombre, String descripcion, String objetivo, String nivel, int duracion,int puntajeMinimo, int autorId) {
        super(nombre, descripcion, objetivo, nivel,duracion, autorId);
        this.puntajeMinimo = puntajeMinimo;
    }

    public void agregarPregunta(Pregunta pregunta){
        preguntas.put(pregunta.getId(), pregunta);
    }

    @Override
    public String getTipo() {
        return "Quiz";
    }

    @Override
    public String getContenido() {
        String retorno= "Realizar el quiz: \n";
        for (Pregunta pregunta : preguntas.values()) {
            retorno = retorno + pregunta.getEnunciado();
            for (Integer key : pregunta.getOpciones().keySet()) {
                retorno = retorno + "\n\t" + key + ". " + pregunta.getOpciones().get(key);
            }
            retorno = retorno + "\n";
        }

        return retorno;
    }

    @Override
    public Actividad copiar(int autorId) {
        Quiz copia = new Quiz(this.nombre, this.descripcion, this.objetivo, this.nivel, this.duracion, this.puntajeMinimo, autorId);
        for (Pregunta pregunta : preguntas.values()) {
            copia.agregarPregunta(pregunta);
        }
        return copia;
    }

    @Override
    public String toString(){
        String formato = super.toString();
        formato += "Quiz\n";
        for (Pregunta pregunta : preguntas.values()) {
            formato += pregunta.getId() + "\n";
        }
        formato += puntajeMinimo + "\n";
        return formato;
    }

    public static Quiz fromStringArray(String[] data) {
        // Verificamos que el array tenga suficientes elementos
        if (data.length < 9) {
            throw new IllegalArgumentException("Datos insuficientes para crear una instancia de Quiz.");
        }
    
        // Parseamos los datos básicos
        int id = Integer.parseInt(data[0]);
        String nombre = data[1];
        String descripcion = data[2];
        String objetivo = data[3];
        String nivel = data[4];
        int duracion = Integer.parseInt(data[5]);
        int autorId = Integer.parseInt(data[6]);
    
        // Última línea específica del Quiz contiene el puntaje mínimo
        int puntajeMinimo = Integer.parseInt(data[data.length - 1]);
    
        // Crear la instancia de Quiz sin preguntas inicialmente
        Quiz quiz = new Quiz(id, nombre, descripcion, objetivo, nivel, duracion, puntajeMinimo, autorId);
    
        // Agregar los IDs de preguntas que se encuentran después de la línea "Quiz"
        for (int i = 8; i < data.length - 1; i++) {
            int preguntaId = Integer.parseInt(data[i]);
            // Aquí solo se agrega el ID; las preguntas deberán añadirse en otro momento
            quiz.preguntas.put(preguntaId, null);
        }
    
        return quiz;
    }
    
    public HashMap<Integer, Pregunta> getPreguntas() {
        return preguntas;
    }

    public void setPreguntas(HashMap<Integer, Pregunta> preguntas) {
        this.preguntas = preguntas;
    }

    public int getPuntajeMinimo() {
        return puntajeMinimo;
    }

    public void setPuntajeMinimo(int puntajeMinimo) {
        this.puntajeMinimo = puntajeMinimo;
    }
}
