package com.dpoo.Persistencia.actividades;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.LearningPath;
import com.dpoo.Entidades.actividades.Tarea;

public class PersistenciaLearningPaths {
    private static final String DIR_PATH = "dpoo/data/entidades/learningPaths/";

    public static void guardarLearningPath(LearningPath learningPath) {
        String path = DIR_PATH + learningPath.getId() + ".txt";
        try {
            FileWriter writer = new FileWriter(path);
            writer.write(learningPath.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static LearningPath cargarLearningPath(String[] content, HashMap<Integer, Actividad> actividades) {
        return LearningPath.cargarDesdeString(content, actividades);
    }

    public static HashMap<Integer, LearningPath> cargarLearningPaths(HashMap<Integer, Actividad> actividades) {
        HashMap<Integer, LearningPath> learningPaths = new HashMap<>();
        File dir = new File(DIR_PATH);
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File file : files) {
                    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                        String content = new String(Files.readAllBytes(Paths.get(file.getPath())),
                                StandardCharsets.UTF_8);
                        String[] parts = content.split("\n");
                        LearningPath learningPath = cargarLearningPath(parts, actividades);
                        learningPaths.put(learningPath.getId(), learningPath);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return learningPaths;
    }
}
