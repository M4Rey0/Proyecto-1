package com.dpoo.Entidades.actividades;

import java.util.HashMap;

public class Pregunta {
    private int id;
    private String enunciado;
    private HashMap<Integer, String> opciones = new HashMap<>();
    private int respuestaCorrecta;

    public Pregunta(String enunciado, HashMap<Integer, String> opciones, int respuestaCorrecta) {
        this.enunciado = enunciado;
        this.opciones = opciones;
        this.respuestaCorrecta = respuestaCorrecta;
    }

    public boolean verificarRespuesta(int respuesta) {
        return respuesta == respuestaCorrecta;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }

    public HashMap<Integer, String> getOpciones() {
        return opciones;
    }

    public void setOpciones(HashMap<Integer, String> opciones) {
        this.opciones = opciones;
    }

    public int getRespuestaCorrecta() {
        return respuestaCorrecta;
    }

    public void setRespuestaCorrecta(int respuestaCorrecta) {
        this.respuestaCorrecta = respuestaCorrecta;
    }
}
