package com.dpoo.Gestores;

import java.util.ArrayList;
import java.util.HashMap;

import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.LearningPath;
import com.dpoo.Entidades.Usuario;
import com.dpoo.Entidades.usuarios.Profesor;

public class GestorPrincipal {
    private static GestorPrincipal instance = null;
    private GestorUsuarios gestorUsuarios = new GestorUsuarios();
    private GestorActividades gestorActividades = new GestorActividades();
    private GestorLearningPaths gestorLearningPaths = new GestorLearningPaths();

    private GestorPrincipal() {
        gestorActividades = new GestorActividades();
        gestorActividades.cargarActividades();
        gestorUsuarios = new GestorUsuarios();
        gestorUsuarios.cargarUsuarios(gestorActividades.getActividades());
        gestorLearningPaths = new GestorLearningPaths();
        gestorLearningPaths.cargarLearningPaths(gestorActividades.getActividades(), gestorUsuarios.getEstudiantes());
    }

    public static GestorPrincipal getInstance() {
        if (instance == null) {
            instance = new GestorPrincipal();
        }
        return instance;
    }

    public void crearUsuario(Usuario usuario) {
        gestorUsuarios.agregarUsuario(usuario);
    }

    public void borrarUsuario(int id) {
        gestorUsuarios.borrarUsuario(id);
    }

    public void agregarActividad(Actividad actividad) {
        gestorActividades.agregarActividad(actividad);
        gestorUsuarios.agregarActividad(actividad.getAutorId(), actividad);
    }

    public void agregarLearningPath(LearningPath learningPath) {
        gestorLearningPaths.agregarLearningPath(learningPath);
    }

    public void inscribirEstudiante(int learningPathId, int estudianteId) {
        gestorLearningPaths.inscribirEstudiante(learningPathId, estudianteId, false);
    }

    public void desinscribirEstudiante(int learningPathId, int estudianteId) {
        gestorLearningPaths.desinscribirEstudiante(learningPathId, estudianteId);
    }

    public void agregarRating(int actividadId, int usuarioId, float rating) {
        gestorActividades.agregarRating(actividadId, usuarioId, rating);
    }

    public float obtenerRating(int actividadId, int usuarioId) {
        return gestorActividades.obtenerRating(actividadId, usuarioId);
    }

    public HashMap<Integer, Float> getRatingsActividad(int idActividad) {
        return gestorActividades.getRatings().get(idActividad);
    }

    public void agregarActividadALearningPath(Actividad actividad, int idLearningPath) {
        gestorLearningPaths.agregarActividadALearningPath(actividad, idLearningPath);
    }

    public void quitarActividadDeLearningPath(int actividadId, int idLearningPath) {
        gestorLearningPaths.quitarActividadDeLearningPath(actividadId, idLearningPath);
    }

    public void borrarActividad(int actividadId) {
        Actividad actividad = gestorActividades.obtenerActividad(actividadId);
        gestorActividades.quitarActividad(actividadId);
        gestorUsuarios.quitarActividad(actividadId, actividad);
        actividad = null;
    }

    public Actividad obtenerActividad(int id) {
        return gestorActividades.obtenerActividad(id);
    }

    public LearningPath obtenerLearningPath(int learningPathId) {
        return gestorLearningPaths.obtenerLearningPath(learningPathId);
    }

    public Usuario obtenerUsuario(int id) {
        return gestorUsuarios.obtenerUsuario(id);
    }

    public void hacerActividadLearningPath(int idLearningPath, int idEstudiante, int idActividad) {
        gestorLearningPaths.cambiarProgresoActividad(idLearningPath, idActividad, idEstudiante, 2);
    }

    public Usuario iniciarSesion(String username, String password) {
        return gestorUsuarios.validarUsuario(username, password);
    }
    
    public HashMap<Integer, Actividad> getActividades() {
        return gestorActividades.getActividades();
    }

    public ArrayList<Actividad> getActividadesProfesor(int profesorId) {
        Profesor profesor = gestorUsuarios.obtenerProfesor(profesorId);
        ArrayList<Actividad> actividades = new ArrayList<>();
        if (profesor == null) {
            return actividades;
        }
        for (Actividad actividad : profesor.getActividadesCreadas()) {
            actividades.add(actividad);
        }

        return actividades;
    }

    public ArrayList<LearningPath> getLearningPaths() {
        HashMap<Integer, LearningPath> learningPaths = gestorLearningPaths.getLearningPaths();
        ArrayList<LearningPath> learningPathsList = new ArrayList<>();
        for (LearningPath learningPath : learningPaths.values()) {
            learningPathsList.add(learningPath);
        }
        return learningPathsList;
    }
}   
