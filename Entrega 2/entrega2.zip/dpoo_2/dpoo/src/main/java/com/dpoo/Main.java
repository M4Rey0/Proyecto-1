package com.dpoo;

import com.dpoo.Gestores.GestorPrincipal;
import com.dpoo.Interfaz.InterfazTest;

public class Main {
    public static void main(String[] args) {
        InterfazTest interfaz = new InterfazTest();
        interfaz.ejecutar();
    }
}