package com.dpoo.Persistencia.actividades;

import com.dpoo.Entidades.Actividad;
import com.dpoo.Entidades.actividades.Examen;
import com.dpoo.Entidades.actividades.Quiz;
import com.dpoo.Entidades.actividades.Recurso;
import com.dpoo.Entidades.actividades.Tarea;

public class FactoryActividades {

    public static Actividad cargarActividad(String[] content){
        Actividad actividad = null;

        switch (content[7]) {
            case "Examen":
                actividad = crearExamen(content);
                break;
            case "Recurso":
                actividad = crearRecurso(content);
                break;
            case "Quiz":
                actividad = crearQuiz(content);
                break;
            case "Tarea":
                actividad = crearTarea(content);
                break;
            default:
                actividad = null;
                break;
        }
        return actividad;
    }

    private static Actividad crearTarea(String[] content){
        return Tarea.fromStringArray(content);
    }

    private static Actividad crearRecurso(String[] content){
        return Recurso.fromStringArray(content);
    }

    private static Actividad crearExamen(String[] content){
        return Examen.fromStringArray(content);
    }

    private static Actividad crearQuiz(String[] content){
        return Quiz.fromStringArray(content);
    }
}
