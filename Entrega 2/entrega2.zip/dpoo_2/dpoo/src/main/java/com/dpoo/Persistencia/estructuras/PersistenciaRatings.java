package com.dpoo.Persistencia.estructuras;

import java.io.FileWriter;
import java.nio.file.Files;
import java.util.HashMap;

public class PersistenciaRatings {
    private static final String DIR_PATH = "dpoo/data/estructuras/ratings/";

    public static void guardarRatings(int idActividad, HashMap<Integer, Float> ratings) {
        String path = DIR_PATH + idActividad + ".txt";
        try {
            String contenido = idActividad + "\n";
            for (Integer idEstudiante : ratings.keySet()) {
                contenido += idEstudiante + " " + ratings.get(idEstudiante) + "\n";
            }
            FileWriter writer = new FileWriter(path);
            writer.write(contenido);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static HashMap <Integer, Float> cargarRatings(int idActividad) {
        HashMap <Integer, Float> ratings = new HashMap<>();
        try {
            String path = DIR_PATH + idActividad + ".txt";
            String content = new String(Files.readAllBytes(java.nio.file.Paths.get(path)));
            String[] lines = content.split("\n");
            for (int i = 1; i < lines.length; i++) {
                String[] parts = lines[i].split(" ");
                ratings.put(Integer.parseInt(parts[0]), Float.parseFloat(parts[1]));
            }
        } catch (Exception e) {
            
        }
        return ratings;
    }
}
